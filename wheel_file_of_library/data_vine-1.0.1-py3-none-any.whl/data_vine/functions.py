from . import json_a
from . import schema
from . import create_file
import os
import re


def createDelta(tableName, oldState, newState, method, updatedAt, pkeyName=None, pkey=None):
    try:
        delta = []
        path = f'AVRO/{tableName}/'
        create_file.createDir(path)
        if method == "PUT":
            # flag = 0
            # for index, eachRow in enumerate(oldState):
            #     if eachRow[pkeyName] == newState[index][pkeyName]:
            #         columns = eachRow.keys()
            #         columns = list(columns)
            #         for column in columns:
            #             if eachRow[column] != newState[index][column]:
            #                 flag = 1
            #                 break
            #         if flag == 1:
            #             break
            #     if flag == 1:
            for eachRow in oldState:
                if eachRow[pkeyName] == pkey:
                    delta.append(eachRow)
                    # print(
                    #     f'AVRO/{tableName}/{eachRow[pkeyName]}/{updatedAt}.avro')
                    create_file.createDir(f'{path}/{eachRow[pkeyName]}')
                    json_a.json_to_avro(
                        delta, f'AVRO/{tableName}/{eachRow[pkeyName]}/{updatedAt}.avro', f'AVSC/{tableName}.avsc')
                    break
        elif method == "POST":
            newRow = newState.pop()
            print(newRow)
            columns = newRow.keys()
            # for column in columns:
            #     if column != pkeyName:
            #         newRow[column] = None
            delta.append(newRow)
            print(delta)
            create_file.createDir(f'{path}/{newRow[pkeyName]}')
            json_a.json_to_avro(
                delta, f'AVRO/{tableName}/{newRow[pkeyName]}/{updatedAt}.avro', f'AVSC/{tableName}.avsc')
        elif method == "DELETE":
            flag = 0
            for index, eachRow in enumerate(newState):
                if eachRow[pkeyName] != oldState[index][pkeyName]:
                    flag = 1
                    print(eachRow)
                    delta.append(eachRow)
                    create_file.createDir(f'{path}/{eachRow[pkeyName]}')
                    json_a.json_to_avro(
                        delta, f'AVRO/{tableName}/{eachRow[pkeyName]}/{updatedAt}.avro', f'AVSC/{tableName}.avsc')
                    break
            if flag == 0:
                print(oldState.pop())
                delta.append(oldState.pop())
                create_file.createDir(f'{path}/{eachRow[pkeyName]}')
                json_a.json_to_avro(
                    delta, f'AVRO/{tableName}/{delta[0][pkeyName]}/{updatedAt}.avro', f'AVSC/{tableName}.avsc')
        else:
            return "NOT A VALID REQUEST"
        updateState(tableName, newState)
    except Exception as e:
        print(e)

# def createDelta(tableName, oldState, newState, method, updatedAt, pkeyName=None):
#     try:
#         delta = []
#         path = f'AVRO/{tableName}'
#         if method == "PUT":
#             flag = 0
#             for index, eachRow in enumerate(oldState):
#                 columns = eachRow.keys()
#                 for column in columns:
#                     if eachRow[column] != newState[index][column]:
#                         flag = 1
#                         break
#                 if flag == 1:
#                     # print(eachRow)
#                     delta.append(eachRow)
#                     create_file.createDir(f'{path}/{eachRow[pkeyName]}')
#                     json_a.json_to_avro(
#                         delta, f'AVRO/{tableName}/{eachRow[pkeyName]}/{updatedAt}.avro', f'AVSC/{tableName}.avsc')
#                     break
#         elif method == "POST":
#             newRow = newState.pop()
#             columns = newRow.keys()
#             for column in columns:
#                 if column != pkeyName:
#                     newRow[column] = None
#             delta.append(newRow)
#             print(delta)
#             create_file.createDir(f'{path}/{newRow[pkeyName]}')
#             json_a.json_to_avro(
#                 delta, f'AVRO/{tableName}/{newRow[pkeyName]}/{updatedAt}.avro', f'AVSC/{tableName}.avsc')
#         elif method == "DELETE":
#             flag = 0
#             for index, eachRow in enumerate(newState):
#                 if eachRow[pkeyName] != oldState[index][pkeyName]:
#                     flag = 1
#                     print(eachRow)
#                     delta.append(eachRow)
#                     create_file.createDir(f'{path}/{eachRow[pkeyName]}')
#                     json_a.json_to_avro(
#                         delta, f'AVRO/{tableName}/{eachRow[pkeyName]}/{updatedAt}.avro', f'AVSC/{tableName}.avsc')
#                     break
#             if flag == 0:
#                 print(oldState.pop())
#                 delta.append(oldState.pop())
#                 create_file.createDir(f'{path}/{delta[0][pkeyName]}')
#                 json_a.json_to_avro(
#                     delta, f'AVRO/{tableName}/{delta[0][pkeyName]}/{updatedAt}.avro', f'AVSC/{tableName}.avsc')
#         else:
#             return "NOT A VALID REQUEST"
#         updateState(tableName, newState)
#     except Exception as e:
#         print(e)


def updateState(tableName, newState):
    try:
        path = f'AVRO/current_state'
        create_file.createDir(path)
        json_a.json_to_avro(
            newState, f'AVRO/current_state/{tableName}.avro', f'AVSC/{tableName}.avsc')
    except Exception as e:
        print(e)


def createAvsc(tableName, columnDetails):
    try:
        avsc = schema.getAvsc(columnDetails, tableName)
        create_file.createAvsc(tableName, avsc)
    except Exception as e:
        print(e)


def getCurrentState(tableName):
    try:
        path = f'AVRO/current_state/{tableName}.avro'
        if create_file.checkPath(path) == 0:
            return "NO TABLE TO SHOW"
        currentState = json_a.avro_to_json(path)
        return currentState
    except Exception as e:
        print(e)


def fetchDeltaHistory(tableName, timeStamp, pkeyName, pkey):
    oldState = []
    currentState = getCurrentState(tableName)
    columns = currentState[0].keys()
    columns = list(columns)
    for eachRow in currentState:
        if eachRow[pkeyName] == pkey:
            oldState.append(eachRow)
            break
    if len(oldState) == 0:
        dic = {}
        for column in columns:
            dic[column] = column
        oldState.append(dic)
    path = f'AVRO/{tableName}/{pkey}/'
    if create_file.checkPath(path) == 0:
        return oldState
    deltapaths = os.listdir(path)
    deltapaths.sort(reverse=True)
    for deltapath in deltapaths:
        match = re.search(r"((\d+)_(\d+))", deltapath)
        if match == None:
            continue
        oldTimeStamp = match.group(1)
        if oldTimeStamp > timeStamp:
            oldRow = json_a.avro_to_json(f'{path}{oldTimeStamp}.avro')
            if len(oldState) > 0:
                # print(oldState)
                if oldRow[0][pkeyName] == oldState[len(oldState)-1][pkeyName]:
                    return oldState
            # if oldRow[0][pkeyName] == pkey:
            oldState.append(oldRow[0])
    return oldState


def fetchDelta(tableName, timeStamp, pkeyName):
    oldState = []
    alteredRows = os.listdir(f'AVRO/{tableName}/')
    alteredRows = list(alteredRows)
    nonAltered = []
    currentState = getCurrentState(tableName)
    for eachRow in currentState:
        # print(alteredRows.index(f'{eachRow[pkeyName]}'))

        if not (alteredRows.index(f'{eachRow[pkeyName]}')+1):
            nonAltered.append(eachRow)
    for eachAltered in alteredRows:
        if nonAltered:
            if int(eachAltered) > nonAltered[0][pkeyName]:
                oldState.append(nonAltered[0])
                nonAltered.pop(0)
        history = fetchDeltaHistory(
            tableName, timeStamp, pkeyName, eachAltered)
        if history:
            oldState.append(history[-1])
    return oldState


# def fetchDelta(tableName, timeStamp, pkeyName):
#     # try:
#     oldState = []
#     currentState = getCurrentState(tableName)
#     # print(currentState)
#     alteredRows = os.listdir(f'AVRO/{tableName}/')
#     for eachRow in currentState:
#         key = eachRow[pkeyName]
#         alteredRows.remove(f'{key}')
#         # print(alteredRows,key,9)
#         path = f'AVRO/{tableName}/{key}/'
#         if create_file.checkPath(path) == 0:
#             continue
#         columns = eachRow.keys()
#         columns = list(columns)
#         deltapaths = os.listdir(path)
#         deltapaths.sort(reverse=True)
#         print(deltapaths)
#         # print(type(eachRow))
#         for deltapath in deltapaths:
#             match = re.search(r"((\d+)_(\d+))", deltapath)
#             if match == None:
#                 continue
#             oldTimeStamp = match.group(1)
#             if oldTimeStamp > timeStamp:
#                 print("bleh")
#                 if columns.index(pkeyName):
#                     columns.remove(pkeyName)
#                 oldRow = json_a.avro_to_json(f'{path}{oldTimeStamp}.avro')
#                 if eachRow[pkeyName] == oldRow[0][pkeyName]:
#                     if deltapaths[-1] == deltapath:
#                         oldState.append(eachRow)
#                         del eachRow
#                         updateState(tableName, currentState)
#                         continue
#                     for column in columns:
#                         eachRow[column] = oldRow[0][column]
#                     oldState.append(eachRow)

    # print(oldRow)
    # for column in columns:
    #     print(column)
    # print(alteredRows)
    # return "this is delta"
    # except Exception as e:
    #     print(e)

# fetchDelta("employees2", '2020013426_159446', "EMP_ID")
# print()
# 20200404_000101
# 20201221_159446
